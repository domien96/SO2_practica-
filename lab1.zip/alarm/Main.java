package alarm;

public class Main {
    
    public static void main(String[] args){
        
        Hospital hospital1 = new Hospital("UZ");
        PoliceDepartment police = new PoliceDepartment();
        
        EmergencyCallCenter callCenter = new EmergencyCallCenter("112");
        callCenter.addListener(hospital1);
        callCenter.addListener(police);
        
        callCenter.incomingCall("crash", "Plateaustraat");
        callCenter.incomingCall("assault", "Veldstraat");
        callCenter.incomingCall("fire", "Zwijnaardse Steenweg");
        
    }
}
