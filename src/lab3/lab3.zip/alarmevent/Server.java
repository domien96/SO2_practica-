
package alarmevent;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import network.Network;


public class Server {

    public static void main(String[] args) throws IOException{
        
        // server code

    }
}
