package network;

public class Connection {

}
