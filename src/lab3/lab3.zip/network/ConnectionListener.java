package network;

// listens for incoming connections
public class ConnectionListener {

}
