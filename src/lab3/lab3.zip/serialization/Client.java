package serialization;

import java.io.*;
import java.net.*;

public class Client {

    public static void main(String[] args) {

        // client code
    }
}
